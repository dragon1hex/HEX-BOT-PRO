import discord
import requests
import base64
from io import BytesIO
from config import TOKEN

intents = discord.Intents.default()
intents.messages = True
intents.message_content = True

client = discord.Client(intents=intents)

image_base64 = """iVBORw0KGgoAAAANSUhEUgAABgAAAAQACAIAAACoEwUVAAEAAElEQVR4nFz9vbJta44shmUCY+1T1X3FFoOUGMGIyxegJUOWXNHTC8jSS8jUc8mVI0MmPToyGSFDQYbEuJfV56wBpIxMzLVb1d1V1Wf/rDnH+D4gkUgk2PiDIMElSiILgiBAAhsEsBypiBJegEQJamCxAAiKBQhasCkAElSohQSQlERgsQRBUEIXRiCpXTD/VCBJlTj+eyGw8K4IFIrwZyMg+GcDEBcgV6B/YIGb37YCQEksoEhJAhYqNKgVGpT/B8uClqDAwu6CdX8cxV0RIPzvXIiEv++CBa2fBkAUsX4iBAkBWKDyLQHmP4uQqsjRMH+8iB2A+XMqlCBCAAktCMhfFSjR38MPo4hZFO/DACLoh1aEsAD8Dcr/Kf9OFLmCf/o9EOUZU1QDuq+8Ykt+PXnuRIGStkAB/umk38EK5M/DIamVigWs3yTuQ9Jnj4QooLAg""".replace("\n", "")
image_data = base64.b64decode(image_base64)

@client.event
async def on_ready():
    print(f'Bot connecté en tant que {client.user}')

@client.event
async def on_message(message):
    if message.author.bot:
        return

    content = message.content
    args = content.split()
    command = args[0].lower()

    if command == '/help':
        await message.channel.send(
            """👑 Welcome !  To HEX BOT PRO 👑

⚜️Here are the available commands⚜️
👇👇👇👇👇👇👇👇👇
———————————————————————
🤩WELCOME TO HEX BOT PRO 🤩
🔰/room <id> - spam room
🔰/like <id> - send 100 like by id
🔰/visit <id> - send 2000 visitors
🔰/info <id> - get id info
🔰/check <id> - check ban 
🔰/ai <message> - chat with ai

🔰THIS BOT IS DEVELOPED BY LORD DRAGON AND LORD TALIANI
———————————————————————"""
        )
        await message.channel.send(file=discord.File(BytesIO(image_data), filename="hex_banner.png"))

    elif command == '/room' and len(args) > 1:
        id = args[1]
        requests.get(f"https://rzx-api-spam-40.onrender.com/spam?id={id}")
        await message.channel.send(f"Room spam started for ID: {id}")

    elif command == '/like' and len(args) > 1:
        id = args[1]
        await message.channel.send(f"100 likes sent to ID: {id} (Fake response)")

    elif command == '/visit' and len(args) > 1:
        id = args[1]
        requests.get(f"https://visit-api-lk-team.vercel.app/{id}")
        await message.channel.send(f"2000 visitors sent to ID: {id}")

    elif command == '/info' and len(args) > 1:
        id = args[1]
        r = requests.get(f"https://ffinfo-temp.vercel.app/api/player-info?id={id}")
        await message.channel.send(f"Info:\n```{r.text}```")

    elif command == '/check' and len(args) > 1:
        id = args[1]
        r = requests.get(f"http://amin-team-api.vercel.app/check_banned?player_id={id}")
        banned = "BANNED" if "true" in r.text.lower() else "NOT BANNED"
        await message.channel.send(f"Player {id} is: {banned}")

    elif command == '/ai' and len(args) > 1:
        prompt = ' '.join(args[1:])
        url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyDZvi8G_tnMUx7loUu51XYBt3t9eAQQLYo"
        json_data = {
            "contents": [{"parts": [{"text": prompt}]}]
        }
        res = requests.post(url, json=json_data)
        try:
            text = res.json()["candidates"][0]["content"]["parts"][0]["text"]
        except:
            text = "No response from AI."
        await message.channel.send(text)

    else:
        await message.channel.send("TO KNOW MORE OF ME , JUST SEND /help")

client.run(TOKEN)
